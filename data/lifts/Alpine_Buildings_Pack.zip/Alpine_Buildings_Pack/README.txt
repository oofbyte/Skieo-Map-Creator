OOF'S ALPINE BUILDINGS  --  building pack for Ski-E-O! Ski Resort Tycoon
=========================================================================

50 new buildings for your resort, all made from scratch for this pack out of the game's own
materials: wood, stone, metal roofs, and windows that light up at night.

GIANTS
  Grand Summit Lodge         giant grand lodge: glazed great hall, cross-gabled wings   (Grand Lodge)
  Grand Alpine Palace Hotel  giant chateau hotel: copper roofs, turrets, portico          (Hotel)

MOUNTAIN HOMES AND CABINS  (they work like the Cabin: same unlock, guests stay in them)
  Timber Ridge Walkout       timber-frame walkout home, stone chimney, covered deck
  Aspen Timber Home          stone walkout level, covered deck, twin trussed dormers
  Black Bear Timber Home     black timber on stone, red metal roof, iron-railed deck
  River Rock Timber Home     heavy-truss portico on river-rock columns, rusty awnings
  Stone Gate Timber Home     trussed portico on stone columns, copper-red roof
  Elk Ridge Timber Home      long red-timber home, green metal roof
  Granite Peak Timber Home   cream timber, stone-column portico, rusty awnings
  Trapper Log Cabin          small rustic log cabin with a front porch
  Creekside Log Home         L-shaped log home, wraparound porch, green roof
  Bear Den Log Lodge         big log home with a log-column portico
  Classic A-Frame            true A-frame with a glazed gable and a deck
  Twin Peaks A-Frame         two A-frames joined by an entry link
  Bernese Chalet             Swiss chalet with deep eaves and balconies all round
  Engadin Stone Chalet       stone and render village house with a barn door
  Edelweiss Guesthouse       big four-storey chalet guesthouse
  Ski-In Townhouses          three attached townhouses
  Village Row Houses         four attached row houses
  Timber Frame Chalet        glazed gable, glass balcony, stone chimney
  Timber Frame Lodge Home    L-shaped, log wing, timber balcony
  Modern Shed-Roof Retreat   dark boards, mono-pitch roof, glass front
  Glass Front Ski House      three storeys with a full glass front
  Log & Glass Chalet         dark logs, shingled roof, glazed gable
  Twin Gable Modern Home     white boards, two gables, glass balcony
  Peak A-Frame               steep A-frame with a two-storey glass gable
  Shed-Roof Ski House        mono-pitch roof and a log wing

MODERN  (homes like the Cabin, the rest like the Grand Lodge or the Hotel)
  Larch Cube Villa           stacked larch boxes, cantilever, roof terrace
  Glass Gable House          minimalist gable with a fully glazed end
  Stone & Glass Retreat      long low stone house with walls of glass
  Split-Level Modern Home    two offset shed-roof volumes
  Larch Balcony Hotel        long hotel with larch balconies, metal top floor        (Hotel)
  Alpine Terrace Hotel       two hotel blocks joined by a glazed link                (Hotel)
  Snowline Design Hotel      three staggered blocks stepping up                      (Hotel)
  Slopeside Apartments       modern apartment house                                  (Grand Lodge)
  Summit Residences          two apartment blocks of different heights               (Grand Lodge)

INNS, GRAND LODGES AND HOTELS  (they work like the stock Grand Lodge or Hotel)
  Village Inn                stone and timber inn with three trussed cross gables    (Grand Lodge)
  Ridgeview Condos           condo lodge of gabled bays with private balconies       (Grand Lodge)
  Canyon Lake Estate         timber pavilions on a stone terrace, glazed great room  (Grand Lodge)
  Silver Lake Estate         dark timber estate with a three-storey glass pavilion   (Grand Lodge)
  Timberline Lake Hotel      three-storey estate hotel, full glass great-room gable  (Hotel)
  Timberline Grand Lodge     stone base, dark timber, dormers, porte-cochere         (Grand Lodge)
  Snowmass Inn               L-shaped stucco and stone inn                           (Grand Lodge)
  Summit Tower Lodge         three wings and a tower                                 (Hotel)
  Twin Tower Log Lodge       long log lodge with a tower at each end                 (Grand Lodge)
  Alpine Grand Hotel         T-shaped stucco grand hotel                             (Hotel)
  Red Timber Resort Hotel    stepped three-wing hotel in red timber                  (Hotel)
  Charcoal Peak Lodge        charcoal timber with a central tower                    (Grand Lodge)
  Eagle Ridge Grand Lodge    long log lodge, two towers, green roof                  (Grand Lodge)
  Highland Grand Lodge       U-shaped cream-timber lodge with a central tower        (Hotel)

Each building costs its stock building's price times 0.65 to 2.4, depending on size. Upkeep and
unlock level are the stock building's, and capacity grows with size. No stock building is changed.

INSTALL
-------
This pack installs with the Ski-E-O Map Creator (version 1.5.0 or later), the only way to install it:
1. Close the game.
2. Open the Map Creator and click Mod Library at the bottom.
3. Switch on "Oof's Alpine Buildings".
4. Start the game: the new buildings are in the build menu under Comfort, next to the Cabin,
   Grand Lodge and Hotel.

The Map Creator keeps the pack working after game updates (each time it starts, it refreshes the
pack's copy of the game's building list from your own game files) and brings the pack up to date when
you update the app. Copying the pack's files into ~mods by hand is not supported.

It works together with the Doppelmayr D-Line R2 Six and R2 Gondola lift packs: switch on any of
them and you get all of their content.

UNINSTALL
---------
Mod Library > switch it off (with the game closed). Take the pack's buildings out of your save first,
or they will be missing when you load.

NOTES
-----
- The two giants are very big (over 120 m long): give them a large, fairly flat spot.
- On the author's PC the game crashes once on the first launch after mod files are added or
  changed, then starts fine. If it happens, just launch the game again.
- A game update can break mods. If the game won't start after an update, switch the pack off in
  the Mod Library.
- Other mods that also replace the building economy table (DT_BuildingEconomy) can clash with
  this one.

CREDITS
-------
- Every building in this pack was made for it: modelled procedurally in Blender (our own
  generator) on the game's own materials. No downloaded models.
- Mod build: custom Blender / Unreal pipeline.
