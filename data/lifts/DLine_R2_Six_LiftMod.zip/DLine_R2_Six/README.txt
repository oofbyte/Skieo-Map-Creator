DOPPELMAYR D-LINE R2 SIX  --  lift mod for Ski-E-O! Ski Resort Tycoon
=======================================================================================

Adds one new lift to the build menu:

    Doppelmayr D-Line R2 Six
      - D-Line R2 glass station, DCD6V six-seat bubble chairs, Doppelmayr support towers

The rope runs level through the station like the real lift. Capacity and speed match
the stock detachable six. It costs and unlocks like the stock
High-Speed Six: 721,200+ in the build menu, 6,000 a day to run, available from Elite Resort.
No other lift or building is changed.

CHANGES -- November 13 (full game)
----------------------------------
- Rebuilt for the full game (Ski-E-O! Ski Resort Tycoon). The demo is no longer supported.
- Price, upkeep and unlock now match the stock High-Speed Six (721,200+, 6,000 a day, Elite Resort).
  Before, it cost what the stock double chair does and was available from level 1.
- The full game's new buildings and decorations (Base Lodge, the autumn set) stay in the
  build menu with the pack installed.
- Installs only through the Ski-E-O Map Creator's Mod Library now (no more copying files by hand).

CHANGES -- October 22
---------------------
- Rebuilt for the October 22 game update.

CHANGES -- October 16
---------------------
- Rebuilt for the October 16 game update (picks up the new stock lift speeds and the
  new top-station queue line); older versions still load but undo those changes.
- New towers: the same full-detail Doppelmayr support tower as the R2 Gondola (Thomas Stendys'
  model), sized for the six-seater. Lifts you already built get them when the save loads.

CHANGES -- October 15
---------------------
- Upkeep lowered to 195 a day -- the same as the stock double chair (it was 6,000 for the
  Six and 20,100 for the Gondola).
- Shorter build-menu description.
- Checked against the October 15 game update: no other changes needed.

CHANGES -- update for the October 14 game patch
-----------------------------------------------
- Fixed: crash to desktop when loading a resort and when clicking the lift in the build
  menu after the game's October 14 update. The pack is rebuilt for the new game version
  (it needs the updated game; update through Steam first).
- Works together with the Doppelmayr D-Line R2 Gondola (Omega V) pack: install both and
  both lifts show up (before, the second pack could hide the first).
- Price lowered to 39,000 -- the same as the stock double chair -- so it is buildable
  outside sandbox. Still unlocked from reputation level 1.

INSTALL
-------
This pack installs with the Ski-E-O Map Creator (version 1.4.0 or later), the only way to install it:
1. Close the game.
2. Open the Map Creator and click Mod Library at the bottom.
3. Switch on "Doppelmayr D-Line R2 Six".
4. Start the game: Build menu > Lifts > "Doppelmayr D-Line R2 Six".

The Map Creator keeps the pack working after game updates (each time it starts, it refreshes the
pack's copy of the game's building list from your own game files) and brings the pack up to date when
you update the app. Copying the pack's files into ~mods by hand is not supported.

USING IT WITH THE R2 GONDOLA
Switch both packs on in the Mod Library and you get both lifts.
It also works with Oof's Alpine Buildings (the building pack in the Mod Library).

UNINSTALL
---------
Mod Library > switch it off (with the game closed). Take the lift out of your save first, or it will be
missing when you load.

NOTES
-----
- On the author's PC the game crashes once on the first launch after mod files are added or
  changed, then starts fine. It did this before this mod too (it looks like a game quirk).
  If it happens, just launch the game again.
- A game update can break mods. If the game won't start after an update, switch the pack off in
  the Mod Library.
- Other mods that also replace the building economy table (DT_BuildingEconomy) can clash with
  this one. If another mod's lifts vanish, that is the likely cause.
- The game crashes at startup if more than about 22 lifts are enabled in the build menu.

CREDITS
-------
- Station and chairs: Doppelmayr's online 3D configurator (configurator.doppelmayr.com),
  used with Doppelmayr's permission. Doppelmayr, D-Line and Omega are Doppelmayr's trademarks;
  this is a fan-made, unofficial mod and is not endorsed by Doppelmayr or the game's developer.
- Towers: "Doppelmayr ski lift tower - upholder" by Thomas Stendys (Tomme123456789,
  3D Warehouse).
- Mod build: custom Blender / Unreal pipeline.
