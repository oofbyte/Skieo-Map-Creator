DOPPELMAYR D-LINE R2 GONDOLA (OMEGA V)  --  lift mod for Ski-E-O! Ski Resort Tycoon
=======================================================================================

Adds one new lift to the build menu:

    Doppelmayr D-Line R2 Gondola (Omega V)
      - D-Line R2 glass station, Omega V-10 cabins, Doppelmayr tubular towers

The rope runs level through the station like the real lift. Capacity and speed match
the stock gondola. It costs and unlocks like the stock
Gondola: 2,414,400+ in the build menu, 20,100 a day to run, available from World-Class.
No other lift or building is changed.

CHANGES -- November 13 (full game)
----------------------------------
- Rebuilt for the full game (Ski-E-O! Ski Resort Tycoon). The demo is no longer supported.
- Price, upkeep and unlock now match the stock Gondola (2,414,400+, 20,100 a day, World-Class).
  Before, it cost what the stock double chair does and was available from level 1.
- The full game's new buildings and decorations (Base Lodge, the autumn set) stay in the
  build menu with the pack installed.

CHANGES -- October 22
---------------------
- Rebuilt for the October 22 game update.

CHANGES -- October 16
---------------------
- Rebuilt for the October 16 game update (picks up the new stock lift speeds and the
  new top-station queue line); older versions still load but undo those changes.
- Station built at the same scale as the Omega V cabins: the R2 station, operator shack,
  platforms, queue and benches are about 1.9x bigger. The two rope lines are 8.4 m apart,
  through the middle of the station's cabin slots, so the station is a little narrower
  across the line than a straight blow-up.
- New towers: a Doppelmayr support tower (Thomas Stendys' model), normal size, with the
  crossarm widened for the 8.4 m gauge and a taller lifting frame.
- Platforms: the corner between the front platform and the big deck is a smooth curve
  (was a 45-degree piece with triangle corners), the sloped ramp behind the operator shack
  is gone, and the decks are paved with the game's own cobblestone path texture.
- Gondolas you already built switch to the new layout when the save loads.

CHANGES -- October 15
---------------------
- Upkeep lowered to 195 a day -- the same as the stock double chair (it was 6,000 for the
  Six and 20,100 for the Gondola).
- Shorter build-menu description.
- Checked against the October 15 game update: no other changes needed.

CHANGES -- update for the October 14 game patch
-----------------------------------------------
- Fixed: crash to desktop when loading a resort and when clicking the lift in the build
  menu after the game's October 14 update. The pack is rebuilt for the new game version
  (it needs the updated game; update through Steam first).
- New queue: it now runs on the concrete, along the front walkway and onto the big deck,
  clear of the operator shack, the benches and the cabins. Gondolas you already built
  keep their old queue line -- place a new one (or edit its queue line) to get it.
- Front walkway 2.5 m deeper so the queue fits on it; the front ramp moved out with it.
- Fixed: the benches were lying on the bare ground beside the station; they are back on
  the deck.
- Fixed: the cabin hanger arm was mirrored; it now curves the way the real Omega V's does.
- Price lowered to 39,000 -- the same as the stock double chair -- so it is buildable
  outside sandbox. Still unlocked from reputation level 1.
- Works together with the Doppelmayr D-Line R2 Six pack.

INSTALL
-------
Easiest: the Ski-E-O Map Creator's Mod Library switches this pack on and off for you, and after
a game update it refreshes the pack's copy of the game's building list from your own game files.
By hand:
1. In Steam: right-click the game > Manage > Browse local files.
2. Open  SkiResortSimulator\Content\Paks
3. If there is no folder called  ~mods  here, create one (the ~ is part of the name).
4. Copy the three files from the "mods_folder_contents" folder of this zip into ~mods:
       ZZZ_DoppelmayrR2Gondola_P.pak
       ZZZ_DoppelmayrR2Gondola_P.ucas
       ZZZ_DoppelmayrR2Gondola_P.utoc
   (all three are needed)
5. Start the game. Build menu > Lifts > "Doppelmayr D-Line R2 Gondola (Omega V)".

USING IT WITH THE R2 SIX PACK
This pack works together with the "Doppelmayr D-Line R2 Six" pack: install both and you get both
lifts. Make sure the Six pack is the current version (an earlier version of it replaced the
game's whole building table and would hide this gondola).

UNINSTALL
---------
Delete the three files from ~mods.  Take the lift out of your save first, or it will be
missing when you load.

NOTES
-----
- On the author's PC the game crashes once on the first launch after mod files are added or
  changed, then starts fine. It did this before this mod too (it looks like a game quirk).
  If it happens, just launch the game again.
- A game update can break mods. If the game won't start after an update, remove the three files.
- Other mods that also replace the building economy table (DT_BuildingEconomy) can clash with
  this one. If another mod's lifts vanish, that is the likely cause.
- The game crashes at startup if more than about 22 lifts are enabled in the build menu.

CREDITS
-------
- Station and cabins: Doppelmayr's online 3D configurator (configurator.doppelmayr.com),
  used with Doppelmayr's permission. Doppelmayr, D-Line and Omega are Doppelmayr's trademarks;
  this is a fan-made, unofficial mod and is not endorsed by Doppelmayr or the game's developer.
- Towers: "Doppelmayr ski lift tower - upholder" by Thomas Stendys (Tomme123456789,
  3D Warehouse).
- Mod build: custom Blender / Unreal pipeline.
